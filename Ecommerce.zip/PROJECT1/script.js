const questions = [
  {
    question: "What is the unit of electric current?",
    options: ["Volt", "Ampere", "Ohm", "Watt"],
    answer: "Ampere",
  },
  {
    question: "Which component is used to store electrical energy?",
    options: ["Resistor", "Capacitor", "Diode", "Transistor"],
    answer: "Capacitor",
  },
  {
    question: "What does a diode do in a circuit?",
    options: [
      "Stores charge",
      "Allows current to flow in one direction",
      "Amplifies signals",
      "Blocks current",
    ],
    answer: "Allows current to flow in one direction",
  },
  {
    question: "What is the primary function of a resistor?",
    options: [
      "To increase current",
      "To restrict current flow",
      "To store energy",
      "To convert AC to DC",
    ],
    answer: "To restrict current flow",
  },
  {
    question: "What is the formula for Ohm’s Law?",
    options: ["V = I/R", "V = IR", "R = VI", "I = VR"],
    answer: "V = IR",
  },
];

let currentQuestionIndex = 0;
let score = 0;

// References to HTML elements
const questionElement = document.getElementById("question");
const answerButtons = document.querySelectorAll(".btn");
const nextButton = document.getElementById("nxt");

// Load a question
function loadQuestion() {
  const currentQuestion = questions[currentQuestionIndex];
  questionElement.textContent = currentQuestion.question;
  answerButtons.forEach((button, index) => {
    button.textContent = currentQuestion.options[index];
    button.classList.remove("selected", "correct", "incorrect");
  });
}

// Handle answer selection
answerButtons.forEach((button) => {
  button.addEventListener("click", () => {
    clearSelection();
    button.classList.add("selected");
  });
});

// Clear any selected option
function clearSelection() {
  answerButtons.forEach((button) => {
    button.classList.remove("selected");
  });
}

// Move to the next question
nextButton.addEventListener("click", () => {
  const selectedButton = document.querySelector(".btn.selected");
  if (!selectedButton) {
    alert("Please select an answer!");
    return;
  }

  const currentQuestion = questions[currentQuestionIndex];
  if (selectedButton.textContent === currentQuestion.answer) {
    selectedButton.classList.add("correct");
    score++;
  } else {
    selectedButton.classList.add("incorrect");
  }

  currentQuestionIndex++;

  if (currentQuestionIndex < questions.length) {
    setTimeout(() => {
      loadQuestion();
    }, 1000);
  } else {
    setTimeout(() => {
      questionElement.textContent = `Quiz Completed! Your score is ${score}/${questions.length}.`;
      answerButtons.forEach((button) => (button.style.display = "none"));
      nextButton.style.display = "none";
    }, 1000);
  }
});

// Initialize the quiz
loadQuestion();
